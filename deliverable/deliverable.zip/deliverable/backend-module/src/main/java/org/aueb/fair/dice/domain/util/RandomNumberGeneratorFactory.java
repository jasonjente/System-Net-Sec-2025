package org.aueb.fair.dice.domain.util;

public class RandomNumberGeneratorFactory {

    // CHECKME
}
