package org.aueb.fair.dice.domain.util;

public class RandomNumberGenerator {

    // Singleton
    public static final RandomNumberGenerator INSTANCE = new RandomNumberGenerator();

    // Generator with security in mind

    public double generateRandomNumber(double seed) {
        return 0.0d;
    }
}
